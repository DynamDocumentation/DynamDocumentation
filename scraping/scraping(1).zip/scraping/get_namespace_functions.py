#namespace: classes e funções e outros namespaces
#classe:
#funções:
#modulos

import requests
from bs4 import BeautifulSoup

import namespace

# URL da página de referência do NumPy
#url = "https://numpy.org/doc/stable/reference/routines.html"



def get_parent_url(url):
    return url.rsplit('/', 1)[0] + '/'

def get_name(url):
    return url.rsplit('/', 1)[1]

def content_namespace(url, the_name):
    x = 1

def get_links_namespace(url):
    # Fazendo a requisição HTTP
    response = requests.get(url)
    links_ = []
    # Verificando se a requisição foi bem-sucedida
    if response.status_code == 200:
        # Parseando o HTML com BeautifulSoup
        soup = BeautifulSoup(response.text, "html.parser")
        url_usage = get_parent_url(url)       
        # Encontrando todos os links dentro da seção principal
        links = soup.select("li a")  # Seleciona links dentro de listas
        for link in links:
            href = link.get("href")
            if href and "generated/" in href:
                full_url = url_usage + href
                links_.append(full_url)
    else:
        print(f"Erro ao acessar a página. Código de status: {response.status_code}")
    return links_

from bs4 import BeautifulSoup
import os

def get_keyword_from_filename(filename):
    filename = os.path.basename(filename).replace(".html", "")
    parts = filename.split(".")

    if len(parts) > 1:
        keyword = parts[1].replace("-package", "").replace("_", "")
    else:
        keyword = parts[0].replace("-package", "").replace("_", "")
    print(keyword)
    if keyword.lower() == "polynomials":
        return "polynomial"
    if keyword.lower() == "emath":
        return "mathematical-functions-with-automatic-domain"
    return keyword.lower()

def remove_links_and_spans(section):
    for tag in section.find_all(['a', 'span', 'tbody']):
        tag.decompose()  # Remove completamente a tag e seu conteúdo
    
    return section

def section_remove_inner(section, id):
    main_section = section.find('section', {'id': id})

    if main_section is None:
        print(f"[⚠️] Section com id='{id}' não encontrada dentro da principal.")
        return section  # Retorna o original mesmo sem modificação

    # Remove todas as <section> internas
    for inner_section in main_section.find_all('section'):
        inner_section.decompose()

    return section


def find_similar_section(html_path):
    f = requests.get(html_path)
    soup = BeautifulSoup(f.text, "html.parser")

    keyword = get_keyword_from_filename(html_path)
    if keyword != "index":
        # Tenta encontrar uma <section> cujo ID contenha a keyword
        sections = soup.find_all("section")
        for section in sections:
            section_id = section.get("id", "").lower()
            section = remove_links_and_spans(section)
            
            if keyword in section_id:
                print(f"[✅] Match: id='{section_id}' contém '{keyword}'")
                return section, section_id

        print(f"[⚠️] Nenhuma section encontrada contendo '{keyword}' em {html_path}")
        return None
    return None

# Exemplo
html_files = [
    "docs/routines.polynomials-package.html",
    "docs/random/index.html",
    "docs/routines.linalg.html"
]

def get_note(cont):
    vals = cont.find_all('div', class_="admonition note")
    return vals
    
    
    

def divide_namespace():
    x= 1


if __name__ == "__main__":
    #get_links("https://numpy.org/doc/stable/reference/routines.html")
    namespaces = namespace.return_namespace()
    for url in namespaces:
        #print(url)
        links = get_links_namespace(url)
        print("nome:", get_name(url))
        if get_name(url) != "index.html":
            section, section_id = find_similar_section(url)
            notes = get_note(section)
            section = section_remove_inner(section, section_id)
            
                
            print(section)
            print(notes)
            
        #for l in links: print(l)
        print("\n\n\n")
