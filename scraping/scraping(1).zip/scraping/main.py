

"""
https://numpy.org/doc/stable/reference/constants.html #unica diferente
"""
